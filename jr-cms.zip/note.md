cms-> content management system

users -> client
students
M -> N
courses
M -> N
teachers

CI & CD
continuous integration
continuous deployment
